class MyArray:
    def __init__(self):
        self.array = []

    def get_array(self, length):
        for i in range(length):
            element = input("Enter element " + str(i+1) + ": ")
            self.array.append(element)
        return sorted(self.array)
