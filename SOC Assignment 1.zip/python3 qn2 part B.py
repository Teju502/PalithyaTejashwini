# Part B
import numpy as np

# Creating a 4x4 2D numpy array with random float values between 0 and 1
random_arr = np.random.uniform(0, 1, size=(4, 4))

# Print the resulting numpy array
print(random_arr)
