# Part C of question 2

# Part A
import numpy as np

# Create a 4x4 2D array using a nested list
arr = [[1, 2, 3, 4],
       [5, 6, 7, 8],
       [9, 10, 11, 12],
       [13, 14, 15, 16]]

# Convert the 2D list to a NumPy array
arr_np = np.array(arr)

# Extract the diagonal elements from the array
diagonal = np.diag(arr_np)
print("Diagonal elements:", diagonal)

# Find the trace of the matrix
trace = np.trace(arr_np) #arr_np as the input
print("Trace of the matrix:", trace)

# Find the max and min element of each row in the matrix
max_each_row = np.amax(arr_np, axis=1)
min_each_row = np.amin(arr_np, axis=1)
print("Maximum element of each row:", max_each_row)
print("Minimum element of each row:", min_each_row)


# Part B
import numpy as np

# Creating a 4x4 2D numpy array with random float values between 0 and 1
random_arr = np.random.uniform(0, 1, size=(4, 4))

# Print the resulting numpy array
print(random_arr)