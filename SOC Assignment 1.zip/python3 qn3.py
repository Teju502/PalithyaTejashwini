import pandas as pd
from dateutil.parser import parse

df = pd.read_csv('Data.csv') #given file is taken as Data.csv
df['Date'] = df['Date'].apply(lambda x: parse(x))
df['month_year'] = df['Date'].dt.to_period('M')
avg_by_month = df.groupby('month_year')['Close'].mean()
avg_by_month.index = avg_by_month.index.strftime('%B')
print(avg_by_month)
